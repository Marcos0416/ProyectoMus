Manual de Descarga y Uso del APK
Descargar e Instalar el APK
Descarga el archivo APK desde la sección de Releases del repositorio.

En tu dispositivo Android, habilita la opción de instalar aplicaciones de orígenes desconocidos (si no está activada).

Abre el archivo APK descargado desde el explorador de archivos o notificación de descarga.

Sigue las instrucciones para instalar la aplicación.

Uso de la Aplicación
Abre la aplicación instalada desde el menú de aplicaciones de tu dispositivo.

Navega por el menú principal para acceder a:

Tutoriales para aprender sobre el Mus.

Tests para evaluar tus conocimientos.

Partidas interactivas para practicar con bots.

Sección de señales para dominar el lenguaje del juego.

Consulta los tutoriales para comprender reglas, puntuación y estrategias.

Realiza tests para recibir feedback y mejorar tus habilidades.

Juega partidas simuladas para poner en práctica lo aprendido.

Requisitos
Dispositivo Android con versión mínima.

Espacio libre para la instalación del APK.
